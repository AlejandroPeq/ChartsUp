-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-06-2016 a las 08:29:13
-- Versión del servidor: 10.1.9-MariaDB
-- Versión de PHP: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tfgdatabase`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aportaciones`
--

CREATE TABLE `aportaciones` (
  `id_aportacion` int(11) NOT NULL,
  `nombre_usuario` varchar(100) NOT NULL,
  `ediciones` int(10) NOT NULL,
  `url_usuario` varchar(100) NOT NULL,
  `id_wiki` int(20) NOT NULL,
  `fecha_inicio` varchar(100) NOT NULL,
  `url_avatar` varchar(500) NOT NULL,
  `ediciones_totales_usuario` int(11) NOT NULL DEFAULT '0',
  `wikis_participa_usuario` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comparaciones`
--

CREATE TABLE `comparaciones` (
  `id_comparacion` int(11) NOT NULL,
  `nombre_wiki` varchar(50) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `id_wiki` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ideas_futuro`
--

CREATE TABLE `ideas_futuro` (
  `id_idea_futuro` int(20) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `resumen` varchar(200) NOT NULL,
  `descripcion` longtext NOT NULL,
  `imagen_adjunta` varchar(100) DEFAULT NULL,
  `fecha_idea` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `ideas_futuro`
--

INSERT INTO `ideas_futuro` (`id_idea_futuro`, `titulo`, `resumen`, `descripcion`, `imagen_adjunta`, `fecha_idea`) VALUES
(1, 'Add on Github', 'Incorporate Github to collaborative platforms supported', 'At the heart of GitHub is Git, an open source project started by Linux creator Linus Torvalds. Matthew McCullough, a trainer at GitHub, explains that Git, like other version control systems, manages and stores revisions of projects. Although it’s mostly used for code, McCullough says Git could be used to manage any other type of file, such as Word documents or Final Cut projects. Think of it as a filing system for every draft of a document.<BR><BR>\r\n\r\nSome of Git’s predecessors, such as CVS and Subversion, have a central “repository” of all the files associated with a project. McCullough explains that when a developer makes changes, those changes are made directly to the central repository. With distributed version control systems like Git, if you want to make a change to a project you copy the whole repository to your own system. You make your changes on your local copy, then you “check in” the changes to the central server. McCullough says this encourages the sharing of more granular changes since you don’t have to connect to the server every time you make a change.<BR><BR>\r\n\r\nGitHub is a Git repository hosting service, but it adds many of its own features. While Git is a command line tool, GitHub provides a Web-based graphical interface. It also provides access control and several collaboration features, such as a wikis and basic task management tools for every project.<BR><BR>\r\n\r\nThe flagship functionality of GitHub is “forking” – copying a repository from one user’s account to another. This enables you to take a project that you don’t have write access to and modify it under your own account. If you make changes you’d like to share, you can send a notification called a “pull request” to the original owner. That user can then, with a click of a button, merge the changes found in your repo with the original repo.<BR><BR>\r\n\r\nThese three features – fork, pull request and merge – are what make GitHub so powerful. Gregg Pollack of Code School (which just launched a class called TryGit) explains that before GitHub, if you wanted to contribute to an open source project you had to manually download the project’s source code, make your changes locally, create a list of changes called a “patch” and then e-mail the patch to the project’s maintainer. The maintainer would then have to evaluate this patch, possibly sent by a total stranger, and decide whether to merge the changes.<BR><BR>\r\n\r\n\r\n\r\n', 'githubPopup.jpg', '2016-05-08'),
(2, 'Add on StackOverflow', 'Incorporate Stackoverflow to collaborative platforms supported', 'Text describing the idea of adding stackoverflow to the platform\r\n\r\n\r\n\r\n', 'stackPopup.jpg', '2016-05-24'),
(3, 'Grow Database', '\r\nAdd more consistent and complete information to our database', 'Add more consistent and complete information to our database information to improve the tool and make it more powerful', 'databasePopup.jpg', '2016-05-11'),
(4, 'Add Wikipedia', 'Incorporate Wikipedia to collaborative platforms supported', 'Text describing the idea of adding Wikipedia to the platform\r\n\r\n\r\n\r\n', 'wikipediaPopup.jpg', '2016-05-31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logros`
--

CREATE TABLE `logros` (
  `id_logro` int(11) NOT NULL,
  `nombre_usuario` varchar(100) NOT NULL,
  `puntos` int(20) NOT NULL,
  `url_imagen_logro` varchar(200) NOT NULL,
  `descripcion_logro` varchar(200) NOT NULL,
  `id_wiki` int(20) NOT NULL,
  `url_avatar_usuario` varchar(200) NOT NULL,
  `titulo_logro` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `novedades_app`
--

CREATE TABLE `novedades_app` (
  `id_novedad` int(11) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `resumen` varchar(200) NOT NULL,
  `descripcion` longtext NOT NULL,
  `version` double(3,2) NOT NULL,
  `fecha` date NOT NULL,
  `url_imagen_novedad` varchar(300) NOT NULL,
  `tipo` enum('bbdd','tool','collaborative','desarrollo','panel','special_tool') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `novedades_app`
--

INSERT INTO `novedades_app` (`id_novedad`, `titulo`, `resumen`, `descripcion`, `version`, `fecha`, `url_imagen_novedad`, `tipo`) VALUES
(1, 'Novedad ColStooy', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-03-17', 'wrench.png', 'tool'),
(3, 'Novedad en BBDD', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-04-05', 'database.png', 'bbdd'),
(4, 'Novedad Panel Gráfico', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-04-20', 'chart.png', 'panel'),
(5, 'Novedad wikia', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-01-15', 'social.png', 'collaborative'),
(6, 'Desarrollo1', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-04-04', 'web.png', 'desarrollo'),
(7, 'Desarrollo 2', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-08-06', 'web.png', 'desarrollo'),
(8, 'Desarrollo 3', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-06-16', 'web.png', 'desarrollo'),
(12, 'Novedad en BBDD', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-04-05', 'database.png', 'bbdd'),
(13, 'Novedad ColStooy', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 1.00, '2016-04-04', 'wrench.png', 'tool'),
(19, 'BBDD Update', 'Primnera novedad a modo de prueba para ver que tal funciona', 'Esta es una descripción más extensa de todo lo que se ha realizado nuevo y cómo se ha abordado.', 2.00, '2016-05-29', 'database.png', 'bbdd');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `id_pregunta` int(20) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `encabezado_descripcion` varchar(200) NOT NULL DEFAULT 'Response',
  `descripcion` longtext NOT NULL,
  `imagen_adjunta` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`id_pregunta`, `titulo`, `encabezado_descripcion`, `descripcion`, `imagen_adjunta`) VALUES
(1, 'What is this application and what is its purpose ?', 'Response', 'This application is a tool for analysis, visualization and data collection in an interactive way on each collaborative entity.', NULL),
(2, 'How many collaborative entities support this application?', 'Response', 'Currently this application only supports a collaborative entity. In the future, the idea is to support all of them , so it is a compact and helpful tool for all people who are interested in these areas.', NULL),
(3, 'How I can I contact the user support team ?', 'Response', '', NULL),
(4, '\r\nCan I compare different entities of my choice ?', 'Response', '', NULL),
(5, 'Can I export somehow my modifications in the graphics?', 'Response', '', NULL),
(6, '\r\nCan you have a personal and custom profile to store your preferences?', 'Response', '', NULL),
(7, 'How often the application information is updated ?', 'Response', '', NULL),
(8, 'How reliable is the information displayed in the application?', 'Response', '', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `wikis`
--

CREATE TABLE `wikis` (
  `id_wiki` int(20) NOT NULL,
  `nombre_wiki` varchar(50) NOT NULL,
  `url` varchar(200) NOT NULL,
  `paginas_contenido` int(10) NOT NULL DEFAULT '0',
  `paginas` int(10) NOT NULL DEFAULT '0',
  `ficheros_subidos` int(10) NOT NULL DEFAULT '0',
  `ediciones_paginas` int(10) NOT NULL DEFAULT '0',
  `media_ediciones` double(5,2) NOT NULL DEFAULT '0.00',
  `usuarios_registrados` int(10) NOT NULL DEFAULT '0',
  `usuarios_activos` int(10) NOT NULL DEFAULT '0',
  `usuarios_administradores` int(10) NOT NULL,
  `usuarios_reversores` int(10) NOT NULL,
  `usuarios_burocratas` int(10) NOT NULL,
  `url_imagen_wiki` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `aportaciones`
--
ALTER TABLE `aportaciones`
  ADD PRIMARY KEY (`id_aportacion`),
  ADD KEY `id_wiki` (`id_wiki`);

--
-- Indices de la tabla `comparaciones`
--
ALTER TABLE `comparaciones`
  ADD PRIMARY KEY (`id_comparacion`),
  ADD KEY `id_wiki` (`id_wiki`);

--
-- Indices de la tabla `ideas_futuro`
--
ALTER TABLE `ideas_futuro`
  ADD PRIMARY KEY (`id_idea_futuro`);

--
-- Indices de la tabla `logros`
--
ALTER TABLE `logros`
  ADD PRIMARY KEY (`id_logro`),
  ADD KEY `id_wiki` (`id_wiki`);

--
-- Indices de la tabla `novedades_app`
--
ALTER TABLE `novedades_app`
  ADD PRIMARY KEY (`id_novedad`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id_pregunta`),
  ADD UNIQUE KEY `titulo` (`titulo`);

--
-- Indices de la tabla `wikis`
--
ALTER TABLE `wikis`
  ADD PRIMARY KEY (`id_wiki`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `aportaciones`
--
ALTER TABLE `aportaciones`
  MODIFY `id_aportacion` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `comparaciones`
--
ALTER TABLE `comparaciones`
  MODIFY `id_comparacion` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `ideas_futuro`
--
ALTER TABLE `ideas_futuro`
  MODIFY `id_idea_futuro` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `logros`
--
ALTER TABLE `logros`
  MODIFY `id_logro` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `novedades_app`
--
ALTER TABLE `novedades_app`
  MODIFY `id_novedad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `id_pregunta` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `wikis`
--
ALTER TABLE `wikis`
  MODIFY `id_wiki` int(20) NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `aportaciones`
--
ALTER TABLE `aportaciones`
  ADD CONSTRAINT `aportaciones_ibfk_1` FOREIGN KEY (`id_wiki`) REFERENCES `wikis` (`id_wiki`);

--
-- Filtros para la tabla `comparaciones`
--
ALTER TABLE `comparaciones`
  ADD CONSTRAINT `comparaciones_ibfk_1` FOREIGN KEY (`id_wiki`) REFERENCES `wikis` (`id_wiki`);

--
-- Filtros para la tabla `logros`
--
ALTER TABLE `logros`
  ADD CONSTRAINT `logros_ibfk_1` FOREIGN KEY (`id_wiki`) REFERENCES `wikis` (`id_wiki`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
